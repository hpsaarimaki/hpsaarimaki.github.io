# 2 Preparing data
# Example script
# HS 6.2.2023

# -

# Set working directory
setwd('C:/Users/sbhesa/Documents/Opetus/Koulutuksia/R workshop 2023/')

# Load data
naming <- read.csv('https://bit.ly/PSY204_naming', sep="")

# Open data frame from Environment panel to examine visually

# Use summary to examine data:
summary(naming)

# Change variable 'male' to a factor
naming$male <- factor(naming$male)
summary(naming)                    # check changes

# Check missing values and outliers:
summary(naming)
boxplot(naming[c(1,2,4)])        # pick only numeric variables
boxplot(naming$iq)

# Recode outlier as missing data:
naming$iq[which(naming$iq > 200)] <- NA
summary(naming)                  # check changes
boxplot(naming$iq)

# Test how to calculate mean for variables with missing data
mean(naming$iq)                  # gives an NA
mean(naming$iq, na.rm=TRUE)      # works

# Add a new variable based on an existing variable:
naming$reading.group <- 'low'
naming$reading.group[which(naming$hrs > 3.5)] <- 'medium'
naming$reading.group[which(naming$hrs > 4.5)] <- 'high'
naming$reading.group <- factor(naming$reading.group)  # tells R this is a categorical variable

# For descriptive stats, useful to take data where one
# subject is only once.
naming_subset <- naming[1:1000,]
# or alternatively:
# naming_subset <- naming
# naming_subset[which(naming$word == "exceptional")] <- NULL

# Attach data frame
attach(naming_subset)

# Descriptive stats
library(psych)
describe(naming_subset)

# Descriptive stats separately for categories:
tapply(iq, list(male, reading.group), mean, na.rm=T)
tapply(iq, list(male, reading.group), sd, na.rm=T)

# Contingency tables:
table(male, reading.group)
prop.table(table(male, reading.group), margin=1)

# Histogram and quantile-quantile-plot:
hist(iq)
qqnorm(iq)
qqline(iq, col = "red")           # Add qqline to plot

# Normality testing:
shapiro.test(iq)
ks.test(iq, "pnorm", mean=mean(iq, na.rm=T), sd=sd(iq, na.rm=T))

