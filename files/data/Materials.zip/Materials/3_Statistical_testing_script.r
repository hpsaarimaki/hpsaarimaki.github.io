# 3 Statistical testing
# Example script
# HS 6.2.2023

# -

# Set working directory
setwd('C:/Users/sbhesa/Documents/Opetus/Koulutuksia/R workshop 2023/')

# -

# Data preparations

# Load data
naming <- read.csv('https://bit.ly/PSY204_naming', sep="")

# Change variable 'male' to a factor
naming$male <- factor(naming$male)

# Recode outlier as missing data:
naming$iq[which(naming$iq > 200)] <- NA

# Add a new variable based on an existing variable:
naming$reading.group <- 'low'
naming$reading.group[which(naming$hrs > 3.5)] <- 'medium'
naming$reading.group[which(naming$hrs > 4.5)] <- 'high'
naming$reading.group <- factor(naming$reading.group)  # tells R this is a categorical variable

# Save data in wide format
library(tidyr)
naming.wide <- pivot_wider(naming, names_from = "word.type",
                           values_from = "ms")

# -

# 1. Categorical variables

# Let's use dataset with one row per individual
attach(naming.wide)

# Contigency table
table(male, reading.group)
# Save table
freq.table <- table(male, reading.group)
write.csv(freq.table, 'freq_table.csv')

# Visualize contingency table
plot(table(male, reading.group))

# Chi square test
chisq.test(male, reading.group)

# -

# 2. T tests

# Check assumptions
# Histograms:
par(mfrow=c(2,1))
hist(regular, main='Regular words', xlab='Reading time (ms)')
hist(exception, main='Exceptional words', xlab='Reading time (ms)')
# Shapiro-Wilk:
shapiro.test(regular)
shapiro.test(exception)

# One-sample t-test
t.test(regular, mu=1000)

# Two-samples t-test
t.test(regular ~ male)
# visualization
library(dplyr)
library(ggplot2)
naming.wide %>%
  ggplot( aes(x=male, y=regular, fill=male)) +
  geom_boxplot() +
  theme(
    legend.position="none",
    plot.title = element_text(size=11)
  ) +
  xlab("") +
  ylab("Reading time (ms)")
  scale_x_discrete(labels=c("0" = "Female", "1" = "Male"))

# Repeated measures t-test
t.test(regular, exception, paired=T)
# visualization
naming %>%
  ggplot( aes(x=word.type, y=ms, fill=word.type)) +
  geom_boxplot() +
  theme(
    legend.position="none",
    plot.title = element_text(size=11)
  ) +
  xlab("Word type") +
  ylab("Reading time (ms)") 

# ---

# 3. Between-subjects ANOVA

# Check assumptions: homogeneity of variance
library(car)
leveneTest(regular ~ reading.group)
leveneTest(exception ~ reading.group)

# -

# One-way between-subjects ANOVA
A1 <- aov(regular ~ reading.group)
summary(A1)

# Diagnostic plots
par(mfrow=c(2,2))
plot(A1)

# Post hoc
pairwise.t.test(regular, reading.group)

# Group means
model.tables(A1)

# Visualization
library(forcats)
naming.wide %>%
  mutate(reading.group = fct_relevel(reading.group, 
                            "low","medium","high")) %>%
  ggplot( aes(x=reading.group, y=regular, fill=reading.group)) +
  geom_boxplot() +
  theme(
    legend.position="none",
    plot.title = element_text(size=11)
  ) +
  xlab("Time spent reading each week") +
  ylab("Reading time (ms)")

# -

# Two-way between-subjects ANOVA
A2 <- aov(exception ~ reading.group*male)
summary(A2)

# Post hoc
pairwise.t.test(exception, reading.group)

# Group means
model.tables(A2)

# Visualization
naming.wide %>% 
  mutate(reading.group = fct_relevel(reading.group, 
                                     "low","medium","high")) %>%
  ggplot() +
  aes(x = reading.group, color = male, group = male, y = exception) +
  stat_summary(fun.y = mean, geom = "point") +
  stat_summary(fun.y = mean, geom = "line") +
  ylim(c(1050, 1250)) +
  xlab("Time spent reading each week") +
  ylab("Reading time (ms)") +
  scale_color_discrete(name = "Gender", labels = c("Female", "Male"))

# ---

# 4. Correlations

# Correlation between two variables:
cor.test(iq,hrs) # pearson
cor.test(iq,hrs, method="spearman")

# Scatterplot between two variables:
plot(iq, hrs)

# Correlation matrix:
corr.test(naming.wide[c(1,2,5,6)])
corr.test(naming.wide[c(1,2,5,6)], method="spearman")
corr.test(naming.wide[c(1,2,5,6)], method="spearman", adjust="bonferroni")

# Basic scatterplot matrix
plot(naming.wide[c(1,2,5,6)])

# Correlogram: scatterplot matrix and histograms
library(GGally)
ggpairs(naming.wide[c(1,2,5,6)]) 

# Conditional plots:
coplot(hrs ~ exception | male)

# Make it nicer:
ggplot(naming.wide, aes(x=exception, y=hrs)) +
  stat_smooth(method = "lm") +
  geom_point() +
  facet_wrap(~ male) 

# Partial correlation:
library(psych)
partial.r(data=naming.wide, x=c("regular","exception"), y="iq")

# -

# 5. Linear regression

# Simple model

# Build and save model:
simple.model <- lm(exception ~ iq)

# Results:
summary(simple.model)

# Diagnostic plots
par(mfrow=c(2,2))
plot(simple.model)

# -

# Model with two predictors

# Build and save model:
main.effect.model <- lm(exception ~ iq + hrs)

# Results:
summary(main.effect.model)

# Diagnostic plots
par(mfrow=c(2,2))
plot(main.effect.model)

# Multicollinearity
library(car)
vif(main.effect.model)

# Compare models
anova(simple.model, main.effect.model)

# -

# Model with two predictors and their interaction effects

# Build and save model:
interaction.model <- lm(exception ~ iq * hrs)

# Results:
summary(interaction.model)

# Diagnostic plots
par(mfrow=c(2,2))
plot(interaction.model)

# Multicollinearity
library(car)
vif(interaction.model, type="predictor")

# Compare models
anova(main.effect.model, interaction.model)

# ---